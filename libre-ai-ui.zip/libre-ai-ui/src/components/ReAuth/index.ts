import auth from './src/auth';

const Auth = auth;

export { Auth };
