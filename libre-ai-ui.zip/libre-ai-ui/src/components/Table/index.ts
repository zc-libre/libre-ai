export { default as BasicTable } from './src/BasicTable.vue';
export { default as TableAction } from './src/TableAction.vue';
