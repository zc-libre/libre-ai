import CountTo from './index.vue';

export { CountTo };
