export default {
  path: '/chat',
  name: 'ChatLayout',
  component: () => import('@/layout/index.vue'),
  redirect: '/chat/conversation',
  meta: {
    icon: 'ep:chat-dot-round',
    title: '聊天',
    rank: 10
  },
  children: [
    {
      path: 'conversation/:uuid?',
      name: 'Chat',
      component: () => import('@/views/chat/index.vue'),
      meta: {
        title: '聊天',
        showLink: true
      }
    }
  ]
} as RouteConfigsTable