import { computed, ref } from 'vue';
import { ElMessage } from 'element-plus';
import { useDashboardStore } from './useDashboardStore';
import type { DashboardRequest } from '@/api/dashboard-generator';
import type { ComponentConfig } from '../types';
import { buildComponentConfig } from '../utils/configBuilder';
import {
  generateDashboard as apiGenerateDashboard,
  generateDashboardStream,
  saveHistory,
  optimizeDashboardStream as apiOptimizeDashboardStream
} from '@/api/dashboard-generator';

export interface GenerationProgress {
  step: number;
  total: number;
  message: string;
  percentage: number;
}

export interface GenerationResult {
  html: string;
  css: string;
  javascript: string;
  linesOfCode: number;
  components: number;
  fileSize: string;
  description: string;
  timestamp: number;
}

export const useDashboardGenerator = () => {
  const store = useDashboardStore();

  // 生成状态
  const generationProgress = ref<GenerationProgress>({
    step: 0,
    total: 6,
    message: '',
    percentage: 0
  });

  const generationResult = ref<GenerationResult | null>(null);
  const streamingCode = ref<string>(''); // 流式接收的代码
  const isStreaming = ref(false); // 是否正在流式接收
  const abortController = ref<AbortController | null>(null); // 用于中止流式请求
  const retryCount = ref(0); // 重试次数
  const maxRetries = 3; // 最大重试次数

  // 生成步骤（导出供组件复用，避免重复定义）
  const generationSteps = [
    '正在分析您的配置',
    '正在设计看板布局',
    '看板生成完成'
  ];

  // 计算属性
  const isGenerating = computed(() => store.isGenerating);
  const canGenerate = computed(() => store.isConfigComplete);

  // 生成看板代码（流式版本，带重试机制）
  const generateDashboardWithStream = async (
    retry = false
  ): Promise<GenerationResult | null> => {
    if (!canGenerate.value) {
      ElMessage.warning('请完成所有必要的配置');
      return null;
    }

    if (!retry) {
      retryCount.value = 0;
    }

    store.setGenerating(true);
    store.setIsStreaming(true);
    store.setStreamingCode('');
    generationResult.value = null;
    streamingCode.value = '';
    isStreaming.value = true;

    try {
      // 更新进度 - 开始生成
      generationProgress.value = {
        step: 0,
        total: generationSteps.length,
        message: '准备生成看板...',
        percentage: 10
      };

      // 准备API请求参数
      const { wizardData, generationOptions } = store;

      // 构建组件配置数组 - 使用新的配置构建工具
      const componentConfigs: ComponentConfig[] = wizardData.componentIds.map(
        (id: string) => {
          const rawConfig = wizardData.componentDataConfigs?.[id] || {};
          return buildComponentConfig(id, rawConfig);
        }
      );

      const request: DashboardRequest = {
        purpose: wizardData.purpose,
        purposeDetail: wizardData.purposeDetail || '',
        focusMetrics: wizardData.focusMetrics || '',
        customRequirements: wizardData.customRequirements || '',
        layout: wizardData.layout,
        theme: {
          name: wizardData.themeText || wizardData.theme,
          colors: {
            primary: wizardData.themeColors?.primary || '#409EFF',
            secondary: wizardData.themeColors?.secondary || '#79BBFF',
            accent: wizardData.themeColors?.accent || '#A0CFFF'
          }
        },
        components: wizardData.componentIds,
        componentConfigs: componentConfigs,
        codeType: generationOptions.codeType || 'html', // 添加代码类型字段
        options: {
          responsive: generationOptions.responsive !== false,
          includeData: generationOptions.includeData !== false,
          additionalRequirements: generationOptions.additionalRequirements || ''
        }
      };

      // 调用流式API
      generationProgress.value = {
        step: 2,
        total: generationSteps.length,
        message: 'AI正在生成代码...',
        percentage: 30
      };

      // 使用流式接口
      abortController.value = await generateDashboardStream(
        request,
        // onChunk - 接收每个代码片段
        (chunk: string) => {
          streamingCode.value += chunk;
          console.log('chunk', chunk);
          console.log(
            'containsNewLine',
            chunk.includes('\n') || chunk.includes('\r')
          );
          store.setStreamingCode(streamingCode.value); // 更新store中的流式代码

          // 动态更新进度
          const currentLength = streamingCode.value.length;
          const estimatedTotal = 5000; // 估计的总长度
          generationProgress.value.percentage = Math.min(
            90,
            (currentLength / estimatedTotal) * 60 + 30
          );
        },
        // onComplete - 完成时的处理
        (fullContent: string) => {
          // 转换为结果格式
          const result: GenerationResult = {
            html: fullContent,
            css: '', // 已内嵌在HTML中
            javascript: '', // 已内嵌在HTML中
            linesOfCode: fullContent.split('\n').length,
            components: wizardData.componentIds.length,
            fileSize: `${Math.round(fullContent.length / 1024)}KB`,
            description: `基于${wizardData.themeText || '默认'}主题的${wizardData.layoutText}看板已生成完成，包含${wizardData.componentIds.length}个组件。`,
            timestamp: Date.now()
          };

          generationResult.value = result;
          isStreaming.value = false;
          store.setIsStreaming(false);
          // 清空流式代码，因为生成已完成
          store.setStreamingCode('');

          // 更新进度 - 保存历史
          generationProgress.value = {
            step: 4,
            total: generationSteps.length,
            message: '保存生成历史...',
            percentage: 95
          };

          // 保存到后端历史记录
          saveHistory({
            config: request,
            generatedHtml: result.html,
            generatedCss: result.css,
            generatedJs: result.javascript
          }).catch(error => {
            console.error('保存历史记录失败:', error);
          });

          // 保存到本地存储
          store.updateWizardData({ generatedResult: result });
          store.saveToHistory();

          // 完成
          generationProgress.value = {
            step: generationSteps.length - 1,
            total: generationSteps.length,
            message: '生成完成！',
            percentage: 100
          };

          store.setGenerating(false);
          ElMessage.success('看板生成成功！');
        },
        // onError - 错误处理与重试
        async (error: Error) => {
          console.error('Generation error:', error);
          isStreaming.value = false;
          store.setIsStreaming(false);
          store.setGenerating(false);

          // 判断是否可以重试
          if (retryCount.value < maxRetries) {
            retryCount.value++;
            ElMessage.warning(
              `生成失败，正在重试 (${retryCount.value}/${maxRetries})...`
            );
            // 延迟 2 秒后重试
            await new Promise(resolve => setTimeout(resolve, 2000));
            return generateDashboardWithStream(true);
          } else {
            ElMessage.error(
              error.message || '生成失败，请检查网络连接并稍后重试'
            );
          }
        }
      );

      return generationResult.value;
    } catch (error: any) {
      console.error('Generation error:', error);
      isStreaming.value = false;
      store.setIsStreaming(false);
      store.setGenerating(false);
      // 清空流式代码
      store.setStreamingCode('');

      // 判断是否可以重试
      if (retryCount.value < maxRetries) {
        retryCount.value++;
        ElMessage.warning(
          `生成失败，正在重试 (${retryCount.value}/${maxRetries})...`
        );
        // 延迟 2 秒后重试
        await new Promise(resolve => setTimeout(resolve, 2000));
        return generateDashboardWithStream(true);
      } else {
        ElMessage.error(error.message || '生成失败，请检查网络连接并稍后重试');
        return null;
      }
    }
  };

  // 生成看板代码（原有非流式版本，保留作为备用）
  const generateDashboard = async (): Promise<GenerationResult | null> => {
    if (!canGenerate.value) {
      ElMessage.warning('请完成所有必要的配置');
      return null;
    }

    store.setGenerating(true);
    generationResult.value = null;

    try {
      // 更新进度 - 开始生成
      generationProgress.value = {
        step: 0,
        total: generationSteps.length,
        message: '准备生成看板...',
        percentage: 10
      };

      // 准备API请求参数
      const { wizardData, generationOptions } = store;
      const request: DashboardRequest = {
        purpose: wizardData.purpose,
        purposeDetail: wizardData.purposeDetail || '',
        focusMetrics: wizardData.focusMetrics || '',
        customRequirements: wizardData.customRequirements || '',
        layout: wizardData.layout,
        theme: {
          name: wizardData.themeText || wizardData.theme,
          colors: {
            primary: wizardData.themeColors?.primary || '#409EFF',
            secondary: wizardData.themeColors?.secondary || '#79BBFF',
            accent: wizardData.themeColors?.accent || '#A0CFFF'
          }
        },
        components: wizardData.componentIds,
        codeType: generationOptions.codeType || 'html', // 添加代码类型字段
        options: {
          responsive: generationOptions.responsive !== false,
          includeData: generationOptions.includeData !== false,
          additionalRequirements: generationOptions.additionalRequirements || ''
        }
      };

      // 调用后端API生成代码
      generationProgress.value = {
        step: 2,
        total: generationSteps.length,
        message: 'AI正在生成代码...',
        percentage: 50
      };

      const response = (await apiGenerateDashboard(request)) as {
        result?: any;
      };

      // 后端返回的是 R<T> 格式，数据在 result 字段中
      if (!response.result) {
        throw new Error('生成失败：未收到有效响应');
      }

      const apiResult = response.result;

      // 转换API响应为前端格式
      const result: GenerationResult = {
        html: apiResult.html,
        css: '', // 已内嵌在HTML中
        javascript: '', // 已内嵌在HTML中
        linesOfCode: apiResult.html.split('\n').length,
        components: wizardData.componentIds.length,
        fileSize: `${Math.round(apiResult.html.length / 1024)}KB`,
        description: `基于${wizardData.themeText || '默认'}主题的${wizardData.layoutText}看板已生成完成，包含${wizardData.componentIds.length}个组件。`,
        timestamp: Date.now()
      };

      generationResult.value = result;

      // 更新进度 - 保存历史
      generationProgress.value = {
        step: 4,
        total: generationSteps.length,
        message: '保存生成历史...',
        percentage: 80
      };

      // 保存到后端历史记录
      try {
        await saveHistory({
          config: request,
          generatedHtml: result.html,
          generatedCss: result.css,
          generatedJs: result.javascript
        });
      } catch (saveError) {
        console.error('保存历史记录失败:', saveError);
        // 不影响主流程
      }

      // 保存到本地存储
      store.updateWizardData({ generatedResult: result });
      store.saveToHistory();

      // 完成
      generationProgress.value = {
        step: generationSteps.length - 1,
        total: generationSteps.length,
        message: '生成完成！',
        percentage: 100
      };

      ElMessage.success('看板生成成功！');
      return result;
    } catch (error: any) {
      ElMessage.error(error.message || '生成失败，请重试');
      console.error('Generation error:', error);
      return null;
    } finally {
      store.setGenerating(false);
    }
  };

  // 下载代码
  const downloadCode = (result: GenerationResult) => {
    // 只需要下载一个完整的HTML文件
    const blob = new Blob([result.html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'dashboard.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    ElMessage.success('看板文件下载完成');
  };

  // 预览代码
  const previewCode = (result: GenerationResult) => {
    // HTML已经是完整的文档，直接打开预览
    const previewWindow = window.open('', '_blank');
    if (previewWindow) {
      previewWindow.document.write(result.html);
      previewWindow.document.close();
    }
  };

  // 中止流式生成
  const abortGeneration = () => {
    if (abortController.value) {
      abortController.value.abort();
      abortController.value = null;
      streamingCode.value = '';
      isStreaming.value = false;
      store.setGenerating(false);
      store.setIsStreaming(false);
      store.setStreamingCode('');
      ElMessage.info('已中止生成');
    }
  };

  // 优化功能
  const optimizationController = ref<AbortController | null>(null);
  const optimizationHistory = ref<Array<{ user: string; ai: string }>>([]);

  /**
   * 流式优化仪表板代码
   * 支持对话式迭代优化
   */
  const optimizeDashboard = async (
    conversationId: string,
    currentHtml: string,
    userRequest: string,
    onChunk?: (chunk: string) => void,
    onComplete?: () => void,
    onError?: (error: Error) => void
  ): Promise<void> => {
    try {
      store.setIsStreaming(true);
      store.setStreamingCode(''); // 清空之前的流式代码

      // 使用API函数进行优化
      optimizationController.value = await apiOptimizeDashboardStream(
        {
          conversationId,
          currentHtml,
          userRequest
        },
        // onChunk - 接收每个代码片段
        (chunk: string) => {
          store.setStreamingCode(store.streamingCode + chunk);
          if (onChunk) {
            onChunk(chunk);
          }
        },
        // onComplete - 完成时的处理
        (fullContent: string) => {
          // 优化完成
          store.setIsStreaming(false);
          // 清空流式代码，因为优化已完成
          store.setStreamingCode('');

          // 更新生成结果
          if (fullContent) {
            generationResult.value = {
              html: fullContent,
              css: '',
              javascript: '',
              linesOfCode: fullContent.split('\n').length,
              components: store.wizardData.componentIds.length,
              fileSize: `${Math.round(fullContent.length / 1024)}KB`,
              description: '优化完成',
              timestamp: Date.now()
            };

            // 更新store中的生成结果
            store.updateWizardData({ generatedResult: generationResult.value });
          }

          if (onComplete) {
            onComplete();
          }

          ElMessage.success('优化完成！');
        },
        // onError - 错误处理
        (error: Error) => {
          console.error('优化错误:', error);
          store.setIsStreaming(false);
          // 清空流式代码
          store.setStreamingCode('');

          if (error.name !== 'AbortError') {
            ElMessage.error(error.message || '优化失败，请重试');
            if (onError) {
              onError(error);
            }
          }
        }
      );
    } catch (error: any) {
      console.error('优化错误:', error);
      store.setIsStreaming(false);
      // 清空流式代码
      store.setStreamingCode('');

      if (error.name !== 'AbortError') {
        ElMessage.error(error.message || '优化失败，请重试');
        if (onError) {
          onError(error);
        }
      }
    }
  };

  // 中止优化
  const abortOptimization = () => {
    if (optimizationController.value) {
      optimizationController.value.abort();
      optimizationController.value = null;
      store.setIsStreaming(false);
      ElMessage.info('已中止优化');
    }
  };

  return {
    // 状态
    generationProgress,
    generationResult,
    isGenerating,
    canGenerate,
    streamingCode,
    isStreaming,

    // 方法
    generateDashboard: generateDashboardWithStream, // 默认使用流式版本
    generateDashboardNonStream: generateDashboard, // 非流式版本作为备用
    downloadCode,
    previewCode,
    abortGeneration,

    // 优化相关
    optimizeDashboard,
    abortOptimization,
    optimizationHistory,

    // 常量
    generationSteps
  };
};
