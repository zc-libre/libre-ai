<script setup lang="ts">
defineOptions({
  name: 'Welcome'
});
</script>

<template>
  <div class="view-centered">
    <div class="text-center">
      <h1 class="text-4xl font-bold text-gray-800 dark:text-white mb-4">
        Pure-Admin-Thin
      </h1>
      <p class="text-lg text-gray-600 dark:text-gray-300 mb-8">国际化版本</p>
      <div class="text-sm text-gray-500 dark:text-gray-400">
        欢迎使用 Pure-Admin-Thin 管理系统
      </div>
    </div>
  </div>
</template>
