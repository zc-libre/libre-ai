import { ref, nextTick } from 'vue'

export function useScroll() {
  const scrollRef = ref<HTMLDivElement>()

  const scrollToBottom = async () => {
    await nextTick()
    if (scrollRef.value) {
      scrollRef.value.scrollTop = scrollRef.value.scrollHeight
    }
  }

  const scrollToTop = async () => {
    await nextTick()
    if (scrollRef.value) {
      scrollRef.value.scrollTop = 0
    }
  }

  const scrollTo = async (top: number) => {
    await nextTick()
    if (scrollRef.value) {
      scrollRef.value.scrollTop = top
    }
  }

  const scrollToBottomIfAtBottom = async () => {
    await nextTick()
    if (scrollRef.value) {
      const { scrollTop, scrollHeight, clientHeight } = scrollRef.value
      const isAtBottom = Math.abs(scrollHeight - clientHeight - scrollTop) <= 100
      if (isAtBottom) {
        scrollRef.value.scrollTop = scrollHeight
      }
    }
  }

  return {
    scrollRef,
    scrollToBottom,
    scrollToTop,
    scrollTo,
    scrollToBottomIfAtBottom
  }
}