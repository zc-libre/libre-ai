import { useChatStore } from '@/store/modules/chat'

export function useChat() {
  const chatStore = useChatStore()

  const updateChat = (
    roomId: number,
    index: number,
    chat: Partial<Chat.Chat>
  ) => {
    const chatData = chatStore.getChatByUuid(roomId)
    if (chatData && chatData[index]) {
      chatStore.updateChatMessage(roomId, index, {
        ...chatData[index],
        ...chat
      })
    }
  }

  const updateChatSome = (
    roomId: number,
    index: number,
    chat: Partial<Chat.Chat>
  ) => {
    updateChat(roomId, index, chat)
  }

  const getChatByUuidAndIndex = (roomId: number, index: number) => {
    const chatData = chatStore.getChatByUuid(roomId)
    return chatData ? chatData[index] : null
  }

  return {
    updateChat,
    updateChatSome,
    getChatByUuidAndIndex
  }
}