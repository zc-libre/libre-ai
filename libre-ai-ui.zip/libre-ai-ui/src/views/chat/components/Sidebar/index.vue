<script setup lang='ts'>
import { computed, onMounted, ref, watch } from 'vue'
import type { CSSProperties } from 'vue'
import { ElButton, ElDialog } from 'element-plus'
import { Icon } from '@iconify/vue'
import { useBasicLayout } from '@/hooks/useBasicLayout'
import { useAppStore } from '@/store/modules/app'
import { useAuthStore } from '@/store/modules/user'
import { useChatStore } from '@/store/modules/chat'
import Footer from './Footer.vue'
import List from './List.vue'

const { t } = useI18n()

const appStore = useAppStore()
const authStore = useAuthStore()
const chatStore = useChatStore()

const { isMobile } = useBasicLayout()
const show = ref(false)
const showNotice = ref(false)
const notice_text = ref('')

const collapsed = computed(() => !appStore.getSidebarStatus)

async function handleAdd() {
  await chatStore.addNewChatRoom()
  if (isMobile.value)
    appStore.setSiderCollapsed(true)
}

function handleUpdateCollapsed() {
  appStore.TOGGLE_SIDEBAR(!collapsed.value)
}

const getChatSidebarClass = computed<CSSProperties>(() => {
  if (isMobile.value) {
    return {
      position: 'fixed',
      zIndex: 50,
    }
  }
  return {}
})

const mobileSafeArea = computed(() => {
  if (isMobile.value) {
    return {
      paddingBottom: 'env(safe-area-inset-bottom)',
    }
  }
  return {}
})

watch(
  isMobile,
  (val) => {
    appStore.TOGGLE_SIDEBAR(!val)
  },
  {
    immediate: true,
    flush: 'post',
  },
)

function closeModal() {
  showNotice.value = false
}

function doNotShowToday() {
  const today = new Date().toDateString()
  localStorage.setItem('announcementLastClosed', today)
  closeModal()
}

onMounted(() => {
  // 初始化聊天室数据
})
</script>

<template>
  <!-- 聊天室侧边栏 -->
  <div
    class="chat-sidebar"
    :class="{
      'chat-sidebar--collapsed': collapsed,
      'chat-sidebar--mobile': isMobile
    }"
    :style="getChatSidebarClass"
  >
    <!-- 折叠控制按钮 -->
    <div 
      v-if="!isMobile"
      class="chat-sidebar__trigger"
      @click="handleUpdateCollapsed"
    >
      <Icon 
        :icon="collapsed ? 'material-symbols:chevron-right' : 'material-symbols:chevron-left'" 
        class="chat-sidebar__trigger-icon"
      />
    </div>

    <!-- 侧边栏内容 -->
    <div 
      class="chat-sidebar__content" 
      :style="mobileSafeArea"
    >
      <main class="chat-sidebar__main">
        <!-- 新建聊天按钮 -->
        <div class="chat-sidebar__header">
          <el-button 
            type="primary"
            class="chat-sidebar__new-chat-btn"
            :disabled="!!authStore.session?.auth && !authStore.token && !authStore.session?.authProxyEnabled"
            @click="handleAdd"
          >
            <Icon icon="material-symbols:add" class="mr-2" />
            {{ t('chat.newChatButton') }}
          </el-button>
        </div>

        <!-- 聊天室列表 -->
        <div class="chat-sidebar__list">
          <List />
        </div>

        <!-- 提示词存储按钮 -->
        <div class="chat-sidebar__actions">
          <el-button 
            class="chat-sidebar__store-btn"
            @click="show = true"
          >
            <Icon icon="material-symbols:storage" class="mr-2" />
            {{ t('store.siderButton') }}
          </el-button>
        </div>
      </main>

      <!-- 底部 -->
      <Footer />
    </div>
  </div>

  <!-- 移动端遮罩 -->
  <div 
    v-if="isMobile && !collapsed" 
    class="chat-sidebar__overlay"
    @click="handleUpdateCollapsed" 
  />

  <!-- 公告弹窗 -->
  <el-dialog
    v-model="showNotice"
    title="公告"
    :width="isMobile ? '90%' : '33%'"
    :close-on-click-modal="false"
  >
    <div class="chat-sidebar__notice">
      <div class="w-full markdown-body" v-html="notice_text" />
    </div>
    <template #footer>
      <div class="chat-sidebar__notice-actions">
        <el-button @click="doNotShowToday">
          今日不再提示
        </el-button>
        <el-button type="primary" @click="closeModal">
          关闭公告
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<style lang="scss" scoped>
.chat-sidebar {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 260px;
  background: var(--el-bg-color);
  border-right: 1px solid var(--el-border-color);
  transform: translateX(0);
  transition: transform 0.3s ease;
  z-index: 10;

  &--collapsed {
    transform: translateX(-100%);
  }

  &--mobile {
    position: fixed;
    z-index: 50;
  }

  &__trigger {
    position: absolute;
    right: -12px;
    top: 50%;
    transform: translateY(-50%);
    width: 24px;
    height: 48px;
    background: var(--el-bg-color);
    border: 1px solid var(--el-border-color);
    border-left: none;
    border-radius: 0 6px 6px 0;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.2s ease;

    &:hover {
      background: var(--el-fill-color-light);
    }
  }

  &__trigger-icon {
    font-size: 16px;
    color: var(--el-text-color-regular);
  }

  &__content {
    display: flex;
    flex-direction: column;
    height: 100%;
  }

  &__main {
    display: flex;
    flex-direction: column;
    flex: 1;
    min-height: 0;
  }

  &__header {
    padding: 16px;
  }

  &__new-chat-btn {
    width: 100%;
    height: 40px;
    border-style: dashed;
  }

  &__list {
    flex: 1;
    min-height: 0;
    overflow: hidden;
    padding-bottom: 16px;
  }

  &__actions {
    padding: 16px;
  }

  &__store-btn {
    width: 100%;
    height: 36px;
  }

  &__overlay {
    position: fixed;
    inset: 0;
    z-index: 40;
    background: rgba(0, 0, 0, 0.4);
  }

  &__notice {
    padding: 16px;
    min-height: 200px;
  }

  &__notice-actions {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
  }
}

// 深色模式适配
.dark .chat-sidebar {
  background: var(--el-bg-color-page);
  border-right-color: var(--el-border-color-darker);

  &__trigger {
    background: var(--el-bg-color-page);
    border-color: var(--el-border-color-darker);

    &:hover {
      background: var(--el-fill-color-darker);
    }
  }
}
</style>