<script setup lang='ts'>
import { defineAsyncComponent, ref } from 'vue'
import { ElButton, ElTooltip } from 'element-plus'
import { Icon } from '@iconify/vue'
import { useAuthStore, useUserStore } from '@/store'
import UserAvatar from '@/components/common/UserAvatar.vue'

const { t } = useI18n()

const Setting = defineAsyncComponent(() => import('@/components/common/Setting/index.vue'))

const authStore = useAuthStore()
const userStore = useUserStore()

const show = ref(false)

async function handleLogout() {
  await authStore.removeToken()
  window.location.reload()
}
</script>

<template>
  <footer class="chat-footer">
    <!-- 用户头像 -->
    <div class="chat-footer__user">
      <UserAvatar v-if="userStore.userInfo" />
      <div v-else class="chat-footer__avatar">
        <Icon icon="ri:user-3-line" />
      </div>
      <span class="chat-footer__username">
        {{ userStore.userInfo?.username || t('common.user') }}
      </span>
    </div>

    <!-- 操作按钮 -->
    <div class="chat-footer__actions">
      <!-- 退出登录 -->
      <el-tooltip 
        v-if="!!authStore.token || !!authStore.session?.authProxyEnabled"
        :content="t('common.logOut')"
        placement="top"
      >
        <button class="chat-footer__btn" @click="handleLogout">
          <Icon icon="uil:exit" />
        </button>
      </el-tooltip>

      <!-- 设置 -->
      <el-tooltip 
        v-if="!!authStore.token || !!authStore.session?.authProxyEnabled"
        :content="t('setting.setting')"
        placement="top"
      >
        <button class="chat-footer__btn" @click="show = true">
          <Icon icon="ri:settings-4-line" />
        </button>
      </el-tooltip>
    </div>

    <!-- 设置弹窗 -->
    <Setting v-if="show" v-model:visible="show" />
  </footer>
</template>

<style lang="scss" scoped>
.chat-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-width: 0;
  padding: 8px 16px;
  border-top: 1px solid var(--el-border-color);

  &__user {
    display: flex;
    align-items: center;
    gap: 8px;
    flex: 1;
    overflow: hidden;
  }

  &__avatar {
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: var(--el-fill-color);
    color: var(--el-text-color-regular);
  }

  &__username {
    font-size: 14px;
    color: var(--el-text-color-primary);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  &__actions {
    display: flex;
    align-items: center;
    gap: 4px;
  }

  &__btn {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    padding: 0;
    background: transparent;
    border: none;
    border-radius: var(--el-border-radius-base);
    cursor: pointer;
    font-size: 20px;
    color: var(--el-text-color-regular);
    transition: all 0.2s;

    &:hover {
      background: var(--el-fill-color-light);
      color: var(--el-color-primary);
    }

    &:active {
      transform: scale(0.95);
    }
  }
}

// 深色模式适配
.dark .chat-footer {
  border-top-color: var(--el-border-color-darker);

  &__avatar {
    background: var(--el-fill-color-darker);
  }

  &__btn {
    color: var(--el-text-color-primary);

    &:hover {
      background: var(--el-fill-color-darker);
      color: var(--el-color-primary);
    }
  }
}
</style>