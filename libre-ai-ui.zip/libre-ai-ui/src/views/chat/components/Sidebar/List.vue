<script setup lang='ts'>
import { computed, onMounted, ref } from 'vue'
import { ElInput, ElPopconfirm, ElScrollbar, ElMessage } from 'element-plus'
import { Icon } from '@iconify/vue'
import { fetchRenameChatRoom } from '@/api/aigc/chat'
import { useBasicLayout } from '@/hooks/useBasicLayout'
import { useAppStore, useChatStore } from '@/store'
import { useAuthStore } from '@/store/modules/auth'
import { debounce } from '@/utils/functions/debounce'

const { t } = useI18n()

const { isMobile } = useBasicLayout()

const appStore = useAppStore()
const chatStore = useChatStore()
const authStore = useAuthStore()

const loadingRoom = ref(false)

const dataSources = computed(() => chatStore.chatRooms)

onMounted(async () => {
  if (authStore.session == null || !authStore.session.auth || authStore.token || authStore.session?.authProxyEnabled)
    await handleSyncChatRoom()
})

async function handleSyncChatRoom() {
  loadingRoom.value = true
  await chatStore.syncHistory()
  loadingRoom.value = false
}

async function handleSelect(item: Chat.ChatRoom) {
  if (isActive(item.roomId))
    return

  await chatStore.setActive(item.roomId)

  if (isMobile.value)
    appStore.setSiderCollapsed(true)
}

async function handleEdit(chatRoom: Chat.ChatRoom, isEdit: boolean) {
  chatRoom.isEdit = isEdit
  if (!chatRoom.isEdit) {
    try {
      await fetchRenameChatRoom(chatRoom.title, chatRoom.roomId)
      ElMessage.success(t('common.success'))
    } catch (error) {
      ElMessage.error(t('common.failed'))
    }
  }
}

function handleDelete(index: number, event?: MouseEvent | TouchEvent) {
  event?.stopPropagation()
  chatStore.deleteChatRoom(index)
  if (isMobile.value)
    appStore.setSiderCollapsed(true)
}

const handleDeleteDebounce = debounce(handleDelete, 600)

function isActive(uuid: number) {
  return chatStore.active === uuid
}
</script>

<template>
  <el-scrollbar class="chat-list">
    <div 
      v-loading="loadingRoom"
      class="chat-list__container"
    >
      <!-- 空数据提示 -->
      <template v-if="!dataSources.length">
        <div class="chat-list__empty">
          <Icon icon="ri:inbox-line" class="chat-list__empty-icon" />
          <span>{{ t('common.noData') }}</span>
        </div>
      </template>
      
      <!-- 聊天室列表 -->
      <template v-else>
        <div 
          v-for="(item, index) of dataSources" 
          :key="index"
          class="chat-list__item"
          :class="{ 'chat-list__item--active': isActive(item.roomId) }"
          @click="handleSelect(item)"
        >
          <Icon icon="ri:message-3-line" class="chat-list__item-icon" />
          
          <div class="chat-list__item-content">
            <el-input
              v-if="item.isEdit"
              v-model="item.title"
              size="small"
              @keydown.enter.stop="handleEdit(item, false)"
              @click.stop
            />
            <span v-else class="chat-list__item-title">{{ item.title }}</span>
          </div>

          <!-- 操作按钮 -->
          <div v-if="isActive(item.roomId)" class="chat-list__item-actions">
            <template v-if="item.isEdit">
              <button class="chat-list__action-btn" @click.stop="handleEdit(item, false)">
                <Icon icon="ri:save-line" />
              </button>
            </template>
            <template v-else>
              <button class="chat-list__action-btn" @click.stop="handleEdit(item, true)">
                <Icon icon="ri:edit-line" />
              </button>
              <el-popconfirm
                :title="t('chat.deleteHistoryConfirm')"
                placement="bottom"
                @confirm="handleDeleteDebounce(index, $event)"
              >
                <template #reference>
                  <button class="chat-list__action-btn" @click.stop>
                    <Icon icon="ri:delete-bin-line" />
                  </button>
                </template>
              </el-popconfirm>
            </template>
          </div>
        </div>
      </template>
    </div>
  </el-scrollbar>
</template>

<style lang="scss" scoped>
.chat-list {
  height: 100%;
  padding: 0 16px;

  &__container {
    display: flex;
    flex-direction: column;
    gap: 8px;
    font-size: 14px;
  }

  &__empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: 16px;
    text-align: center;
    color: var(--el-text-color-secondary);
  }

  &__empty-icon {
    margin-bottom: 8px;
    font-size: 24px;
  }

  &__item {
    position: relative;
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    border: 1px solid var(--el-border-color);
    border-radius: var(--el-border-radius-base);
    cursor: pointer;
    transition: all 0.2s;

    &:hover {
      background-color: var(--el-fill-color-light);
    }

    &--active {
      border-color: var(--el-color-primary);
      background-color: var(--el-fill-color-light);
      color: var(--el-color-primary);
      padding-right: 56px;
    }
  }

  &__item-icon {
    flex-shrink: 0;
    font-size: 18px;
  }

  &__item-content {
    position: relative;
    flex: 1;
    overflow: hidden;
  }

  &__item-title {
    display: block;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  &__item-actions {
    position: absolute;
    right: 4px;
    top: 50%;
    transform: translateY(-50%);
    z-index: 10;
    display: flex;
    align-items: center;
  }

  &__action-btn {
    padding: 4px;
    background: transparent;
    border: none;
    cursor: pointer;
    color: var(--el-text-color-regular);
    transition: color 0.2s;

    &:hover {
      color: var(--el-color-primary);
    }
  }
}

// 深色模式适配
.dark .chat-list {
  &__item {
    border-color: var(--el-border-color-darker);

    &:hover {
      background-color: var(--el-fill-color-darker);
    }

    &--active {
      border-color: var(--el-color-primary);
      background-color: var(--el-fill-color-darker);
    }
  }
}
</style>