<script setup lang="ts">
import { computed } from 'vue'
import { ElButton, ElSwitch, ElTooltip, ElSpace } from 'element-plus'
import { Icon } from '@iconify/vue'

interface Props {
  usingContext?: boolean
  showPrompt?: boolean
  searchEnabled?: boolean
  thinkEnabled?: boolean
}

interface Emit {
  (e: 'export'): void
  (e: 'toggleUsingContext', value: boolean): void
  (e: 'toggleSearchEnabled', value: boolean): void
  (e: 'toggleThinkEnabled', value: boolean): void
  (e: 'toggleShowPrompt'): void
}

const props = defineProps<Props>()
const emit = defineEmits<Emit>()

const { t } = useI18n()

const handleToggleUsingContext = (value: boolean) => {
  emit('toggleUsingContext', value)
}

const handleToggleSearchEnabled = (value: boolean) => {
  emit('toggleSearchEnabled', value)
}

const handleToggleThinkEnabled = (value: boolean) => {
  emit('toggleThinkEnabled', value)
}
</script>

<template>
  <header
    class="sticky top-0 left-0 right-0 z-30 border-b dark:border-neutral-800 bg-white/80 dark:bg-black/20 backdrop-blur"
  >
    <div class="relative flex items-center justify-between min-w-0 overflow-hidden h-14">
      <div class="flex items-center">
        <span class="flex items-center px-4">
          <Icon icon="ri:chat-3-line" class="text-2xl text-primary" />
        </span>
      </div>

      <div class="flex items-center space-x-2 pr-4">
        <el-space>
          <el-tooltip :content="t('chat.usingContext')" placement="bottom">
            <span class="flex items-center">
              <span class="mr-2 text-xs">{{ t('chat.context') }}</span>
              <el-switch
                :model-value="usingContext"
                size="small"
                @update:model-value="handleToggleUsingContext"
              />
            </span>
          </el-tooltip>

          <el-tooltip :content="t('chat.searchEnabled')" placement="bottom">
            <span class="flex items-center">
              <span class="mr-2 text-xs">{{ t('chat.search') }}</span>
              <el-switch
                :model-value="searchEnabled"
                size="small"
                @update:model-value="handleToggleSearchEnabled"
              />
            </span>
          </el-tooltip>

          <el-tooltip :content="t('chat.thinkEnabled')" placement="bottom">
            <span class="flex items-center">
              <span class="mr-2 text-xs">{{ t('chat.think') }}</span>
              <el-switch
                :model-value="thinkEnabled"
                size="small"
                @update:model-value="handleToggleThinkEnabled"
              />
            </span>
          </el-tooltip>

          <el-button text @click="emit('toggleShowPrompt')">
            <template #icon>
              <Icon icon="ri:list-settings-line" />
            </template>
          </el-button>

          <el-button text @click="emit('export')">
            <template #icon>
              <Icon icon="ri:download-2-line" />
            </template>
          </el-button>
        </el-space>
      </div>
    </div>
  </header>
</template>