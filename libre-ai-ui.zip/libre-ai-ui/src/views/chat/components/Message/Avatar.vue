<script lang="ts" setup>
import { computed } from 'vue'
import { ElAvatar } from 'element-plus'
import { Icon } from '@iconify/vue'
import defaultAvatar from '@/assets/avatar.jpg'
import { useUserStore } from '@/store'
import { isString } from '@/utils/is'

interface Props {
  image?: boolean
  onlyDefault?: boolean
}
defineProps<Props>()

const userStore = useUserStore()

const avatar = computed(() => userStore.userInfo.avatar)
</script>

<template>
  <template v-if="image">
    <el-avatar v-if="isString(avatar) && avatar.length > 0 && !onlyDefault" :src="avatar" />
    <el-avatar v-else :src="defaultAvatar" />
  </template>
  <span v-else class="text-[28px] dark:text-white">
    <Icon icon="simple-icons:openai" />
  </span>
</template>