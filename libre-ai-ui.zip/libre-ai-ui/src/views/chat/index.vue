<script setup lang='ts'>
import { computed, defineAsyncComponent, nextTick, onMounted, onUnmounted, ref, watch } from 'vue'
import type { UploadFile } from 'element-plus'
import { ElDialog, ElMessage, ElMessageBox } from 'element-plus'
import html2canvas from 'html2canvas'
import { fetchChatAPIProcessSSE, fetchChatResponseHistory } from '@/api/aigc/chat-sse'
import { useBasicLayout } from '@/hooks/useBasicLayout'
import { useAuthStore } from '@/store/modules/user'
import { useUserStore } from '@/store/modules/user'
import { useChatStore } from '@/store/modules/chat'
import { useAppStore } from '@/store/modules/app'
import { debounce } from '@/utils/functions/debounce'
import Message from './components/Message/index.vue'
import HeaderComponent from './components/Header/index.vue'
import { useChat } from './hooks/useChat'
import { useScroll } from './hooks/useScroll'

const { t } = useI18n()

// const Prompt = defineAsyncComponent(() => import('@/components/common/Setting/Prompt.vue'))

let controller = new AbortController()

const openLongReply = import.meta.env.VITE_GLOB_OPEN_LONG_REPLY === 'true'

const route = useRoute()
const dialog = ElMessageBox
const ms = ElMessage
const authStore = useAuthStore()
const userStore = useUserStore()
const chatStore = useChatStore()

const { isMobile } = useBasicLayout()
const { updateChat, updateChatSome, getChatByUuidAndIndex } = useChat()
const { scrollRef, scrollToBottom, scrollToBottomIfAtBottom, scrollTo } = useScroll()

const { uuid } = route.params as { uuid: string }

const currentChatRoom = computed(() => chatStore.getChatRoomByCurrentActive)
const dataSources = computed(() => chatStore.getChatByUuid(+uuid))
const conversationList = computed(() => dataSources.value.filter(item => (!item.inversion && !!item.conversationOptions)))

const prompt = ref<string>('')
const firstLoading = ref<boolean>(false)
const loading = ref<boolean>(false)
const inputRef = ref<Ref | null>(null)
const showPrompt = ref(false)
const appStore = useAppStore()

const loadingChatUuid = ref<number>(-1)

const currentNavIndexRef = ref<number>(-1)

let loadingms: any
let allmsg: any
let prevScrollTop: number

// 添加PromptStore
// const promptStore = usePromptStore()

// 使用storeToRefs，保证store修改后，联想部分能够重新渲染
// const { promptList: promptTemplate } = storeToRefs<any>(promptStore)

// 未知原因刷新页面，loading 状态不会重置，手动重置
dataSources.value.forEach((item, index) => {
  if (item.loading)
    updateChatSome(+uuid, index, { loading: false })
})

function handleSubmit() {
  onConversation()
}

const uploadFileKeysRef = ref<string[]>([])

async function onConversation() {
  let message = prompt.value

  if (loading.value)
    return

  if (!message || message.trim() === '')
    return

  const uploadFileKeys = uploadFileKeysRef.value
  uploadFileKeysRef.value = []

  controller = new AbortController()

  const chatUuid = Date.now()
  loadingChatUuid.value = chatUuid

  await chatStore.addChatMessage(
    currentChatRoom.value!.roomId,
    {
      uuid: chatUuid,
      dateTime: new Date().toLocaleString(),
      text: message,
      images: uploadFileKeys,
      inversion: true,
      error: false,
      conversationOptions: null,
      requestOptions: { prompt: message, options: null },
    },
  )
  await scrollToBottom()

  loading.value = true
  prompt.value = ''

  let options: Chat.ConversationRequest = {}
  const lastContext = conversationList.value[conversationList.value.length - 1]?.conversationOptions

  if (lastContext && currentChatRoom.value?.usingContext)
    options = { ...lastContext }

  await chatStore.addChatMessage(
    currentChatRoom.value!.roomId,
    {
      uuid: chatUuid,
      dateTime: new Date().toLocaleString(),
      text: '',
      loading: true,
      inversion: false,
      error: false,
      conversationOptions: null,
      requestOptions: { prompt: message, options: { ...options } },
    },
  )
  await scrollToBottom()

  try {
    let lastText = ''
    let accumulatedReasoning = ''
    const fetchChatAPIOnce = async () => {
      let searchQuery: string
      let searchResults: Chat.SearchResult[]
      let searchUsageTime: number

      await fetchChatAPIProcessSSE({
        roomId: currentChatRoom.value!.roomId,
        uuid: chatUuid,
        prompt: message,
        uploadFileKeys,
        options,
        signal: controller.signal,
      }, {
        onSearchQuery: (data) => {
          searchQuery = data.searchQuery
        },
        onSearchResults: (data) => {
          searchResults = data.searchResults
          searchUsageTime = data.searchUsageTime
        },
        onDelta: async (delta) => {
          // Handle incremental data
          if (delta.text) {
            lastText += delta.text
          }
          if (delta.reasoning) {
            accumulatedReasoning += delta.reasoning
          }
          await chatStore.updateChatMessage(
            currentChatRoom.value!.roomId,
            dataSources.value.length - 1,
            {
              dateTime: new Date().toLocaleString(),
              searchQuery,
              searchResults,
              searchUsageTime,
              reasoning: accumulatedReasoning,
              text: lastText,
              inversion: false,
              error: false,
              loading: true,
              conversationOptions: null,
              requestOptions: { prompt: message, options: { ...options } },
            },
          )

          await scrollToBottomIfAtBottom()
        },
        onMessage: async (data) => {
          // Handle complete message data (compatibility mode)
          if (data.searchQuery)
            searchQuery = data.searchQuery
          if (data.searchResults)
            searchResults = data.searchResults
          if (data.searchUsageTime)
            searchUsageTime = data.searchUsageTime

          const usage = (data.detail && data.detail.usage)
            ? {
                completion_tokens: data.detail.usage.completion_tokens || null,
                prompt_tokens: data.detail.usage.prompt_tokens || null,
                total_tokens: data.detail.usage.total_tokens || null,
                estimated: data.detail.usage.estimated || null,
              }
            : undefined

          await chatStore.updateChatMessage(
            currentChatRoom.value!.roomId,
            dataSources.value.length - 1,
            {
              dateTime: new Date().toLocaleString(),
              searchQuery,
              searchResults,
              searchUsageTime,
              reasoning: data?.reasoning,
              text: data.text ?? '',
              inversion: false,
              error: false,
              loading: true,
              conversationOptions: { conversationId: data.conversationId, parentMessageId: data.id },
              requestOptions: { prompt: message, options: { ...options } },
              usage,
            },
          )

          if (openLongReply && data.detail && data.detail.choices?.length > 0 && data.detail.choices[0].finish_reason === 'length') {
            options.parentMessageId = data.id
            lastText = data.text
            message = ''
            return fetchChatAPIOnce()
          }

          await scrollToBottomIfAtBottom()
        },
        onComplete: async (data) => {
          // Handle complete event
          const usage = (data.detail && data.detail.usage)
            ? {
                completion_tokens: data.detail.usage.completion_tokens || null,
                prompt_tokens: data.detail.usage.prompt_tokens || null,
                total_tokens: data.detail.usage.total_tokens || null,
                estimated: data.detail.usage.estimated || null,
              }
            : undefined

          await chatStore.updateChatMessage(
            currentChatRoom.value!.roomId,
            dataSources.value.length - 1,
            {
              dateTime: new Date().toLocaleString(),
              searchQuery,
              searchResults,
              searchUsageTime,
              reasoning: data?.reasoning || accumulatedReasoning,
              text: data?.text || lastText,
              inversion: false,
              error: false,
              loading: false,
              conversationOptions: { conversationId: data.conversationId, parentMessageId: data.id },
              requestOptions: { prompt: message, options: { ...options } },
              usage,
            },
          )
        },
        onError: async (error) => {
          await chatStore.updateChatMessage(
            currentChatRoom.value!.roomId,
            dataSources.value.length - 1,
            {
              dateTime: new Date().toLocaleString(),
              text: error,
              inversion: false,
              error: true,
              loading: false,
              conversationOptions: null,
              requestOptions: { prompt: message, options: { ...options } },
            },
          )
        },
        onEnd: () => {
          updateChatSome(currentChatRoom.value!.roomId, dataSources.value.length - 1, { loading: false })
        },
      })
    }

    await fetchChatAPIOnce()
  }
  catch (error: any) {
    const errorMessage = error?.message ?? t('common.wrong')

    if (error.message === 'canceled') {
      updateChatSome(
        currentChatRoom.value!.roomId,
        dataSources.value.length - 1,
        {
          loading: false,
        },
      )
      await scrollToBottomIfAtBottom()
      return
    }

    const currentChat = getChatByUuidAndIndex(currentChatRoom.value!.roomId, dataSources.value.length - 1)

    if (currentChat?.text && currentChat.text !== '') {
      updateChatSome(
        currentChatRoom.value!.roomId,
        dataSources.value.length - 1,
        {
          text: `${currentChat.text}\n[${errorMessage}]`,
          error: false,
          loading: false,
        },
      )
      return
    }

    updateChat(
      currentChatRoom.value!.roomId,
      dataSources.value.length - 1,
      {
        dateTime: new Date().toLocaleString(),
        text: errorMessage,
        inversion: false,
        error: true,
        loading: false,
        conversationOptions: null,
        requestOptions: { prompt: message, options: { ...options } },
      },
    )
    scrollToBottomIfAtBottom()
  }
  finally {
    loading.value = false
  }
}

async function onRegenerate(index: number) {
  if (loading.value)
    return

  controller = new AbortController()

  const { requestOptions } = dataSources.value[index]
  let responseCount = dataSources.value[index].responseCount || 1
  responseCount++

  let message = requestOptions?.prompt ?? ''

  let options: Chat.ConversationRequest = {}

  if (requestOptions.options)
    options = { ...requestOptions.options }

  loading.value = true
  const chatUuid = dataSources.value[index].uuid
  loadingChatUuid.value = chatUuid!
  updateChat(
    currentChatRoom.value!.roomId,
    index,
    {
      dateTime: new Date().toLocaleString(),
      text: '',
      inversion: false,
      responseCount,
      error: false,
      loading: true,
      conversationOptions: null,
      requestOptions: { prompt: message, options: { ...options } },
    },
  )

  try {
    let lastText = ''
    let accumulatedReasoning = ''
    const fetchChatAPIOnce = async () => {
      let searchQuery: string
      let searchResults: Chat.SearchResult[]
      let searchUsageTime: number

      await fetchChatAPIProcessSSE({
        roomId: currentChatRoom.value!.roomId,
        uuid: chatUuid || Date.now(),
        regenerate: true,
        prompt: message,
        options,
        signal: controller.signal,
      }, {
        onSearchQuery: (data) => {
          searchQuery = data.searchQuery
        },
        onSearchResults: (data) => {
          searchResults = data.searchResults
          searchUsageTime = data.searchUsageTime
        },
        onDelta: async (delta) => {
          // 处理增量数据
          if (delta.text) {
            lastText += delta.text
          }
          if (delta.reasoning) {
            accumulatedReasoning += delta.reasoning
          }

          updateChat(
            currentChatRoom.value!.roomId,
            index,
            {
              dateTime: new Date().toLocaleString(),
              searchQuery,
              searchResults,
              searchUsageTime,
              reasoning: accumulatedReasoning,
              text: lastText,
              inversion: false,
              responseCount,
              error: false,
              loading: true,
              conversationOptions: null,
              requestOptions: { prompt: message, options: { ...options } },
            },
          )

          scrollToBottomIfAtBottom()
        },
        onMessage: async (data) => {
          // Handle complete message data (compatibility mode)
          if (data.searchQuery)
            searchQuery = data.searchQuery
          if (data.searchResults)
            searchResults = data.searchResults
          if (data.searchUsageTime)
            searchUsageTime = data.searchUsageTime
          // Handle complete message data (compatibility mode)
          const usage = (data.detail && data.detail.usage)
            ? {
                completion_tokens: data.detail.usage.completion_tokens || null,
                prompt_tokens: data.detail.usage.prompt_tokens || null,
                total_tokens: data.detail.usage.total_tokens || null,
                estimated: data.detail.usage.estimated || null,
              }
            : undefined
          updateChat(
            currentChatRoom.value!.roomId,
            index,
            {
              dateTime: new Date().toLocaleString(),
              searchQuery,
              searchResults,
              searchUsageTime,
              reasoning: data?.reasoning,
              finish_reason: data?.finish_reason,
              text: data.text ?? '',
              inversion: false,
              responseCount,
              error: false,
              loading: true,
              conversationOptions: { conversationId: data.conversationId, parentMessageId: data.id },
              requestOptions: { prompt: message, options: { ...options } },
              usage,
            },
          )

          if (openLongReply && data.detail && data.detail.choices?.length > 0 && data.detail.choices[0].finish_reason === 'length') {
            options.parentMessageId = data.id
            lastText = data.text
            message = ''
            return fetchChatAPIOnce()
          }

          scrollToBottomIfAtBottom()
        },
        onComplete: async (data) => {
          // 处理完成事件
          const usage = (data.detail && data.detail.usage)
            ? {
                completion_tokens: data.detail.usage.completion_tokens || null,
                prompt_tokens: data.detail.usage.prompt_tokens || null,
                total_tokens: data.detail.usage.total_tokens || null,
                estimated: data.detail.usage.estimated || null,
              }
            : undefined
          updateChat(
            currentChatRoom.value!.roomId,
            index,
            {
              dateTime: new Date().toLocaleString(),
              reasoning: data?.reasoning || accumulatedReasoning,
              finish_reason: data?.finish_reason,
              text: data?.text || lastText,
              inversion: false,
              responseCount,
              error: false,
              loading: false,
              conversationOptions: { conversationId: data.conversationId, parentMessageId: data.id },
              requestOptions: { prompt: message, options: { ...options } },
              usage,
            },
          )
        },
        onError: async (error) => {
          updateChat(
            currentChatRoom.value!.roomId,
            index,
            {
              dateTime: new Date().toLocaleString(),
              text: error,
              inversion: false,
              responseCount,
              error: true,
              loading: false,
              conversationOptions: null,
              requestOptions: { prompt: message, options: { ...options } },
            },
          )
        },
        onEnd: () => {
          updateChatSome(currentChatRoom.value!.roomId, index, { loading: false })
        },
      })
    }
    await fetchChatAPIOnce()
  }
  catch (error: any) {
    if (error.message === 'canceled') {
      updateChatSome(
        currentChatRoom.value!.roomId,
        index,
        {
          loading: false,
        },
      )
      return
    }

    const errorMessage = error?.message ?? t('common.wrong')

    updateChat(
      currentChatRoom.value!.roomId,
      index,
      {
        dateTime: new Date().toLocaleString(),
        text: errorMessage,
        inversion: false,
        responseCount,
        error: true,
        loading: false,
        conversationOptions: null,
        requestOptions: { prompt: message, options: { ...options } },
      },
    )
  }
  finally {
    loading.value = false
  }
}

async function onResponseHistory(index: number, historyIndex: number) {
  const chat = (await fetchChatResponseHistory(currentChatRoom.value!.roomId, dataSources.value[index].uuid || Date.now(), historyIndex)).data
  updateChat(
    currentChatRoom.value!.roomId,
    index,
    {
      dateTime: chat.dateTime,
      reasoning: chat?.reasoning,
      text: chat.text,
      inversion: false,
      responseCount: chat.responseCount,
      error: true,
      loading: false,
      conversationOptions: chat.conversationOptions,
      requestOptions: { prompt: chat.requestOptions.prompt, options: { ...chat.requestOptions.options } },
      usage: chat.usage,
    },
  )
}

function handleExport() {
  if (loading.value)
    return

  ElMessageBox.confirm(t('chat.exportImageConfirm'), t('chat.exportImage'), {
    confirmButtonText: t('common.yes'),
    cancelButtonText: t('common.no'),
    type: 'warning',
  }).then(async () => {
    try {
      const ele = document.getElementById('image-wrapper')
      const canvas = await html2canvas(ele as HTMLDivElement, {
        useCORS: true,
      })
      const imgUrl = canvas.toDataURL('image/png')
      const tempLink = document.createElement('a')
      tempLink.style.display = 'none'
      tempLink.href = imgUrl
      tempLink.setAttribute('download', 'chat-shot.png')
      if (typeof tempLink.download === 'undefined')
        tempLink.setAttribute('target', '_blank')

      document.body.appendChild(tempLink)
      tempLink.click()
      document.body.removeChild(tempLink)
      window.URL.revokeObjectURL(imgUrl)
      ms.success(t('chat.exportSuccess'))
    }
    catch {
      ms.error(t('chat.exportFailed'))
    }
  })
}

function handleDelete(index: number, fast: boolean) {
  if (loading.value)
    return

  if (fast === true) {
    chatStore.deleteChatByUuid(currentChatRoom.value!.roomId, index)
  }
  else {
    ElMessageBox.confirm(t('chat.deleteMessageConfirm'), t('chat.deleteMessage'), {
      confirmButtonText: t('common.yes'),
      cancelButtonText: t('common.no'),
      type: 'warning',
    }).then(() => {
      chatStore.deleteChatByUuid(currentChatRoom.value!.roomId, index)
    })
  }
}

function updateCurrentNavIndex(index: number, newIndex: number) {
  currentNavIndexRef.value = newIndex
}

function handleClear() {
  if (loading.value)
    return

  ElMessageBox.confirm(t('chat.clearChatConfirm'), t('chat.clearChat'), {
    confirmButtonText: t('common.yes'),
    cancelButtonText: t('common.no'),
    type: 'warning',
  }).then(() => {
    chatStore.clearChatByUuid(currentChatRoom.value!.roomId)
  })
}

function handleEnter(event: KeyboardEvent) {
  if (!isMobile.value) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault()
      handleSubmit()
    }
  }
  else {
    if (event.key === 'Enter' && event.ctrlKey) {
      event.preventDefault()
      handleSubmit()
    }
  }
}

async function handleStop() {
  if (loading.value) {
    controller.abort()
    loading.value = false
  }
}

const placeholder = computed(() => {
  if (isMobile.value)
    return t('chat.placeholderMobile')
  return t('chat.placeholder')
})

const buttonDisabled = computed(() => {
  return loading.value || !prompt.value || prompt.value.trim() === ''
})

const footerClass = computed(() => {
  let classes = ['p-4']
  if (isMobile.value)
    classes = ['sticky', 'left-0', 'bottom-0', 'right-0', 'p-2', 'pr-3', 'overflow-hidden']
  return classes
})

function handleFinish(response: any) {
  uploadFileKeysRef.value.push(`${response.data.fileKey}`)
}

function handleDeleteUploadFile() {
  uploadFileKeysRef.value.pop()
}

const uploadHeaders = computed(() => {
  const token = useAuthStore().token
  return {
    Authorization: `Bearer ${token}`,
  }
})

onMounted(() => {
  firstLoading.value = true
  // handleSyncChat()

  if (authStore.token) {
    const chatModels = authStore.session?.chatModels
    if (chatModels != null && chatModels.filter(d => d.value === userStore.userInfo.config.chatModel).length <= 0)
      ms.error('你选择的模型已不存在，请重新选择 | The selected model not exists, please choose again.', { duration: 7000 })
  }
})

onUnmounted(() => {
  if (loading.value)
    controller.abort()
})
</script>

<template>
  <div class="flex flex-col w-full h-full">
    <HeaderComponent
      v-if="isMobile"
      :using-context="currentChatRoom?.usingContext"
      :show-prompt="showPrompt"
      :search-enabled="currentChatRoom?.searchEnabled"
      :think-enabled="currentChatRoom?.thinkEnabled"
      @export="handleExport"
      @toggle-using-context="(v) => chatStore.setUsingContext(v)"
      @toggle-search-enabled="(v) => chatStore.setSearchEnabled(v)"
      @toggle-think-enabled="(v) => chatStore.setThinkEnabled(v)"
      @toggle-show-prompt="showPrompt = true"
    />
    <main class="flex-1 overflow-hidden">
      <div id="scrollRef" ref="scrollRef" class="h-full overflow-hidden overflow-y-auto">
        <div
          id="image-wrapper"
          class="w-full max-w-(--breakpoint-xl) m-auto dark:bg-[#101014]"
          :class="[isMobile ? 'p-2' : 'p-4']"
        >
          <el-loading v-loading="firstLoading">
            <template v-if="!dataSources.length">
              <div class="flex items-center justify-center mt-4 text-center text-neutral-300">
                <el-icon class="mr-2 text-3xl">
                  <svg viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372z"/></svg>
                </el-icon>
                <span>Aha~</span>
              </div>
            </template>
            <template v-else>
              <div>
                <Message
                  v-for="(item, index) of dataSources"
                  :key="String(item.uuid) + String(item.inversion)"
                  :index="index"
                  :current-nav-index="currentNavIndexRef"
                  :date-time="item.dateTime"
                  :search-query="item?.searchQuery"
                  :search-results="item?.searchResults"
                  :search-usage-time="item?.searchUsageTime"
                  :reasoning="item?.reasoning"
                  :finish-reason="item?.finish_reason"
                  :text="item.text"
                  :images="item.images"
                  :inversion="item.inversion"
                  :response-count="item.responseCount"
                  :usage="item && item.usage || undefined"
                  :error="item.error"
                  :loading="item.loading"
                  @regenerate="onRegenerate(index)"
                  @update-current-nav-index="(itemId: number) => updateCurrentNavIndex(index, itemId)"
                  @delete="(fast) => handleDelete(index, fast)"
                  @response-history="(ev) => onResponseHistory(index, ev)"
                />
                <div class="sticky bottom-0 left-0 flex justify-center">
                  <el-button v-if="loading" type="warning" @click="handleStop">
                    <template #icon>
                      <el-icon>
                        <svg viewBox="0 0 1024 1024"><path fill="currentColor" d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372zm-64-276V340c0-4.4 3.6-8 8-8h112c4.4 0 8 3.6 8 8v268c0 4.4-3.6 8-8 8H456c-4.4 0-8-3.6-8-8z"/></svg>
                      </el-icon>
                    </template>
                    Stop Responding
                  </el-button>
                </div>
              </div>
            </template>
          </el-loading>
        </div>
      </div>
    </main>
    <footer :class="footerClass">
      <div class="w-full max-w-(--breakpoint-xl) m-auto">
        <el-space direction="vertical" size="small">
          <div v-if="uploadFileKeysRef.length > 0" class="flex items-center space-x-2 h-10">
            <el-space>
              <img v-for="(v, i) of uploadFileKeysRef" :key="i" :src="`/uploads/${v}`" class="max-h-10">
              <el-button text @click="handleDeleteUploadFile">
                <template #icon>
                  <el-icon class="text-xl text-[#4f555e] dark:text-white">
                    <svg viewBox="0 0 1024 1024"><path fill="currentColor" d="M864 256H736v-80c0-35.3-28.7-64-64-64H352c-35.3 0-64 28.7-64 64v80H160c-17.7 0-32 14.3-32 32s14.3 32 32 32h704c17.7 0 32-14.3 32-32s-14.3-32-32-32zM352 192h320v64H352v-64z"/><path fill="currentColor" d="M832 320H192c-17.7 0-32 14.3-32 32v384c0 70.7 57.3 128 128 128h448c70.7 0 128-57.3 128-128V352c0-17.7-14.3-32-32-32zM760 736c0 35.3-28.7 64-64 64H328c-35.3 0-64-28.7-64-64V384h496v352z"/></svg>
                  </el-icon>
                </template>
              </el-button>
            </el-space>
          </div>

          <div class="flex items-center space-x-2">
            <el-upload
              action="/api/upload-image"
              :headers="uploadHeaders"
              :show-file-list="false"
              :multiple="true"
              accept="image/png, image/jpeg, image/webp, image/gif"
              @success="handleFinish"
            >
              <el-button text class="flex items-center justify-center h-10 transition hover:bg-neutral-100 dark:hover:bg-[#414755]">
                <template #icon>
                  <el-icon class="text-xl text-[#4f555e] dark:text-white">
                    <svg viewBox="0 0 1024 1024"><path fill="currentColor" d="M928 160H96c-17.7 0-32 14.3-32 32v640c0 17.7 14.3 32 32 32h832c17.7 0 32-14.3 32-32V192c0-17.7-14.3-32-32-32zM338 304c35.3 0 64 28.7 64 64s-28.7 64-64 64-64-28.7-64-64 28.7-64 64-64zm513.9 437.1l-192.6-192.6c-12.5-12.5-32.8-12.5-45.3 0L448 714.4l-102.1-102c-12.5-12.5-32.8-12.5-45.3 0L160 752.8V832h704v-90.9z"/></svg>
                  </el-icon>
                </template>
              </el-button>
            </el-upload>
            <el-button text @click="handleClear">
              <template #icon>
                <el-icon class="text-xl text-[#4f555e] dark:text-white">
                  <svg viewBox="0 0 1024 1024"><path fill="currentColor" d="M864 256H736v-80c0-35.3-28.7-64-64-64H352c-35.3 0-64 28.7-64 64v80H160c-17.7 0-32 14.3-32 32s14.3 32 32 32h704c17.7 0 32-14.3 32-32s-14.3-32-32-32zM352 192h320v64H352v-64z"/></svg>
                </el-icon>
              </template>
            </el-button>
            <el-button v-if="!isMobile" text @click="handleExport">
              <template #icon>
                <el-icon class="text-xl text-[#4f555e] dark:text-white">
                  <svg viewBox="0 0 1024 1024"><path fill="currentColor" d="M505.7 661a8 8 0 0 0 12.6 0l112-141.7c4.1-5.2.4-12.9-6.3-12.9h-74.1V168c0-4.4-3.6-8-8-8h-60c-4.4 0-8 3.6-8 8v338.3H400c-6.7 0-10.4 7.7-6.3 12.9l112 141.8z"/><path fill="currentColor" d="M878 626h-60c-4.4 0-8 3.6-8 8v154H214V634c0-4.4-3.6-8-8-8h-60c-4.4 0-8 3.6-8 8v198c0 17.7 14.3 32 32 32h684c17.7 0 32-14.3 32-32V634c0-4.4-3.6-8-8-8z"/></svg>
                </el-icon>
              </template>
            </el-button>
          </div>
          <div class="flex items-center justify-between space-x-2">
            <el-input
              ref="inputRef"
              v-model="prompt"
              type="textarea"
              :placeholder="placeholder"
              :autosize="{ minRows: isMobile ? 1 : 2, maxRows: isMobile ? 4 : 12 }"
              @keypress="handleEnter"
            />
            <el-button type="primary" :disabled="buttonDisabled" @click="handleSubmit">
              <template #icon>
                <el-icon>
                  <svg viewBox="0 0 1024 1024"><path fill="currentColor" d="M931.4 498.9L94.9 79.5c-3.4-1.7-7.3-2.1-11-1.2-8.5 2.1-13.8 10.4-11.7 18.9l27.8 112.1 667.6 86.2 134.6-84.8c-2.6-3.4-6.4-5.8-10.8-6.8zM94.9 944.5l836.5-419.4c4.7-2.4 7.7-7.3 7.9-12.6.2-5.4-2.6-10.4-7.1-13.3L697.6 384.8 162.7 298.5 134.9 410.6c-2.1 8.5 3.2 16.8 11.7 18.9 3.7.9 7.6.5 11-1.2z"/></svg>
                </el-icon>
              </template>
            </el-button>
          </div>
        </el-space>
      </div>
    </footer>
    <!-- <Prompt v-if="showPrompt" v-model:room-id="uuid" v-model:visible="showPrompt" /> -->
  </div>
</template>