import { getToken } from '@/utils/auth'

interface SSECallbacks {
  onSearchQuery?: (data: { searchQuery: string }) => void
  onSearchResults?: (data: {
    searchResults: Chat.SearchResult[]
    searchUsageTime: number
  }) => void
  onDelta?: (delta: Chat.DeltaResponse) => void
  onMessage?: (data: Chat.SSEResponse) => void
  onComplete?: (data: Chat.SSEResponse) => void
  onError?: (error: string) => void
  onEnd?: () => void
}

export async function fetchChatAPIProcessSSE(
  params: {
    roomId: number
    uuid: number
    prompt: string
    uploadFileKeys?: string[]
    options?: Chat.ConversationRequest
    regenerate?: boolean
    signal?: AbortSignal
  },
  callbacks: SSECallbacks
) {
  const token = getToken()
  const baseURL = import.meta.env.VITE_BASE_API || ''

  try {
    const response = await fetch(`${baseURL}/aigc/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({
        roomId: params.roomId,
        uuid: params.uuid,
        prompt: params.prompt,
        uploadFileKeys: params.uploadFileKeys,
        options: params.options,
        regenerate: params.regenerate,
        stream: true
      }),
      signal: params.signal
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const reader = response.body?.getReader()
    const decoder = new TextDecoder()
    let buffer = ''

    while (reader) {
      const { done, value } = await reader.read()
      if (done) {
        callbacks.onEnd?.()
        break
      }

      buffer += decoder.decode(value, { stream: true })
      const lines = buffer.split('\n')
      buffer = lines.pop() || ''

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const data = line.slice(6)
          if (data === '[DONE]') {
            callbacks.onEnd?.()
            return
          }

          try {
            const parsed = JSON.parse(data)

            // 处理搜索查询
            if (parsed.searchQuery) {
              callbacks.onSearchQuery?.({ searchQuery: parsed.searchQuery })
            }

            // 处理搜索结果
            if (parsed.searchResults) {
              callbacks.onSearchResults?.({
                searchResults: parsed.searchResults,
                searchUsageTime: parsed.searchUsageTime || 0
              })
            }

            // 处理增量数据
            if (parsed.delta) {
              callbacks.onDelta?.(parsed.delta)
            }

            // 处理完整消息（兼容模式）
            if (parsed.text !== undefined || parsed.reasoning !== undefined) {
              callbacks.onMessage?.(parsed)
            }

            // 处理完成事件
            if (parsed.finish_reason === 'stop') {
              callbacks.onComplete?.(parsed)
            }
          } catch (e) {
            console.error('Error parsing SSE data:', e)
          }
        }
      }
    }
  } catch (error: any) {
    if (error.name === 'AbortError') {
      callbacks.onError?.('canceled')
    } else {
      callbacks.onError?.(error.message || 'Unknown error')
    }
    callbacks.onEnd?.()
  }
}

export async function fetchChatResponseHistory(
  roomId: number,
  uuid: number,
  historyIndex: number
) {
  // 从本地存储获取历史记录
  const savedChats = localStorage.getItem(`chat_${roomId}`)
  if (savedChats) {
    const chats = JSON.parse(savedChats)
    const chat = chats.find((c: Chat.Chat) => c.uuid === uuid)
    if (chat) {
      return { data: chat }
    }
  }
  return { data: null }
}