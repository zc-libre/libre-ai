import { defineStore } from 'pinia'
import { reactive, computed } from 'vue'
import { router } from '@/router'

class ChatState {
  active: number | null = null
  chatRooms: Chat.ChatRoom[] = []
  chat: { roomId: number; data: Chat.Chat[] }[] = []
}

export const useChatStore = defineStore('chat-store', () => {
  const state = reactive<ChatState>(new ChatState())

  const reloadRoute = async (roomId?: number) => {
    await router.push({ name: 'Chat', params: { uuid: roomId } })
  }

  const findRoomIndex = (roomId: number | null) =>
    state.chatRooms.findIndex(item => item.roomId === roomId)
  const findChatIndex = (roomId: number) =>
    state.chat.findIndex(item => item.roomId === roomId)
  const getCurrentUuid = (uuid?: number) =>
    uuid || state.active || state.chat[0]?.roomId

  // Getters
  const getChatRoomByCurrentActive = computed(
    () => state.chatRooms.find(item => item.roomId === state.active) || null
  )

  const getChatByUuid = computed(() => (uuid?: number) => {
    const targetUuid = getCurrentUuid(uuid)
    return state.chat.find(item => item.roomId === targetUuid)?.data ?? []
  })

  // Actions
  const addNewChatRoom = async () => {
    const title = 'New Chat'
    const roomId = Date.now()

    state.chatRooms.unshift({
      title,
      roomId,
      isEdit: false,
      chatModel: 'claude-sonnet-4-20250514',
      usingContext: true,
      maxContextCount: 10,
      searchEnabled: false,
      thinkEnabled: false
    })

    state.chat.unshift({ roomId, data: [] })
    state.active = roomId
    await reloadRoute(roomId)
  }

  const syncHistory = async () => {
    // 从本地存储加载聊天室
    const savedRooms = localStorage.getItem('chatRooms')
    if (savedRooms) {
      const rooms = JSON.parse(savedRooms)
      state.chatRooms = rooms
      rooms.forEach((r: Chat.ChatRoom) => {
        state.chat.unshift({ roomId: r.roomId, data: [] })
      })
      if (rooms.length > 0) {
        state.active = rooms[0].roomId
      }
    }

    if (state.chatRooms.length === 0) {
      return await addNewChatRoom()
    }
  }

  const syncChat = async (
    room: Chat.ChatRoom,
    lastId?: number,
    callback?: () => void,
    onStart?: () => void,
    onEmpty?: () => void
  ) => {
    if (!room.roomId) return callback?.()

    const roomIndex = findRoomIndex(room.roomId)
    if (
      roomIndex === -1 ||
      state.chatRooms[roomIndex].loading ||
      state.chatRooms[roomIndex].all
    ) {
      if (lastId === undefined) callback?.()
      if (state.chatRooms[roomIndex]?.all) onEmpty?.()
      return
    }

    try {
      state.chatRooms[roomIndex].loading = true
      const chatIndex = findChatIndex(room.roomId)

      // 从本地存储加载聊天历史
      const savedChats = localStorage.getItem(`chat_${room.roomId}`)
      if (savedChats) {
        const chatData = JSON.parse(savedChats)
        if (chatIndex === -1) {
          state.chat.unshift({ roomId: room.roomId, data: chatData })
        } else {
          state.chat[chatIndex].data = chatData
        }
      }
    } finally {
      state.chatRooms[roomIndex].loading = false
      callback?.()
    }
  }

  const addChatMessage = async (roomId: number, chat: Chat.Chat) => {
    const index = findChatIndex(roomId)
    if (index !== -1) {
      state.chat[index].data.push(chat)
      // 保存到本地存储
      localStorage.setItem(
        `chat_${roomId}`,
        JSON.stringify(state.chat[index].data)
      )
    }
  }

  const updateChatMessage = async (
    roomId: number,
    messageIndex: number,
    chat: Chat.Chat
  ) => {
    const index = findChatIndex(roomId)
    if (index !== -1 && state.chat[index].data[messageIndex]) {
      state.chat[index].data[messageIndex] = {
        ...state.chat[index].data[messageIndex],
        ...chat
      }
      // 保存到本地存储
      localStorage.setItem(
        `chat_${roomId}`,
        JSON.stringify(state.chat[index].data)
      )
    }
  }

  const deleteChatByUuid = (roomId: number, messageIndex: number) => {
    const index = findChatIndex(roomId)
    if (index !== -1) {
      state.chat[index].data.splice(messageIndex, 1)
      // 保存到本地存储
      localStorage.setItem(
        `chat_${roomId}`,
        JSON.stringify(state.chat[index].data)
      )
    }
  }

  const clearChatByUuid = (roomId: number) => {
    const index = findChatIndex(roomId)
    if (index !== -1) {
      state.chat[index].data = []
      // 清除本地存储
      localStorage.removeItem(`chat_${roomId}`)
    }
  }

  const setActive = (roomId: number) => {
    state.active = roomId
  }

  const setUsingContext = async (usingContext: boolean) => {
    const index = findRoomIndex(state.active)
    if (index === -1) return

    state.chatRooms[index].usingContext = usingContext
    // 保存到本地存储
    localStorage.setItem('chatRooms', JSON.stringify(state.chatRooms))
  }

  const setSearchEnabled = async (searchEnabled: boolean) => {
    const index = findRoomIndex(state.active)
    if (index === -1) return

    state.chatRooms[index].searchEnabled = searchEnabled
    // 保存到本地存储
    localStorage.setItem('chatRooms', JSON.stringify(state.chatRooms))
  }

  const setThinkEnabled = async (thinkEnabled: boolean) => {
    const index = findRoomIndex(state.active)
    if (index === -1) return

    state.chatRooms[index].thinkEnabled = thinkEnabled
    // 保存到本地存储
    localStorage.setItem('chatRooms', JSON.stringify(state.chatRooms))
  }

  const deleteRoom = async (roomId: number) => {
    const index = findRoomIndex(roomId)
    if (index === -1) return

    state.chatRooms.splice(index, 1)
    const chatIndex = findChatIndex(roomId)
    if (chatIndex !== -1) {
      state.chat.splice(chatIndex, 1)
    }

    // 更新本地存储
    localStorage.setItem('chatRooms', JSON.stringify(state.chatRooms))
    localStorage.removeItem(`chat_${roomId}`)

    // 如果删除的是当前活动房间，切换到第一个房间
    if (state.active === roomId) {
      if (state.chatRooms.length > 0) {
        state.active = state.chatRooms[0].roomId
        await reloadRoute(state.active)
      } else {
        await addNewChatRoom()
      }
    }
  }

  const updateRoom = (roomId: number, room: Partial<Chat.ChatRoom>) => {
    const index = findRoomIndex(roomId)
    if (index !== -1) {
      state.chatRooms[index] = { ...state.chatRooms[index], ...room }
      // 保存到本地存储
      localStorage.setItem('chatRooms', JSON.stringify(state.chatRooms))
    }
  }

  return {
    state,
    getChatRoomByCurrentActive,
    getChatByUuid,
    addNewChatRoom,
    syncHistory,
    syncChat,
    addChatMessage,
    updateChatMessage,
    deleteChatByUuid,
    clearChatByUuid,
    setActive,
    setUsingContext,
    setSearchEnabled,
    setThinkEnabled,
    deleteRoom,
    updateRoom,
    reloadRoute
  }
})